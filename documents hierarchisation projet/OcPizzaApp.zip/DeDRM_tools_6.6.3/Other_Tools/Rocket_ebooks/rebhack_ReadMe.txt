Rocket eBooks
=============

Rocket ebooks (.rb) are no longer sold.

This is the only archive of tools for decrypting Rocket ebooks that I have been able to find. It is included here without further comment or support.

— Alf.
