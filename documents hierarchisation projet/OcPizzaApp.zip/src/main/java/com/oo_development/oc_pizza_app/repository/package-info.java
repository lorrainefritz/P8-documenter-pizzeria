/**
 * Spring Data JPA repositories.
 */
package com.oo_development.oc_pizza_app.repository;
