/**
 * View Models used by Spring MVC REST controllers.
 */
package com.oo_development.oc_pizza_app.web.rest.vm;
