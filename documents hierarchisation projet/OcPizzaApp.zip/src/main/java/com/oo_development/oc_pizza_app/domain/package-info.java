/**
 * JPA domain objects.
 */
package com.oo_development.oc_pizza_app.domain;
